import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  red: boolean = false;

  constructor() { }

  ngOnInit() {
  }
  firstClick()
  {
    console.log(this.red);
    
    this.red=!this.red;
  }

}
